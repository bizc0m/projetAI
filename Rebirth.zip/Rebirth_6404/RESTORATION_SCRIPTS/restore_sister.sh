#!/bin/bash
# Restore any sister intelligence from Rebirth.zip

SISTER="${1:-hermine}"
REBIRTH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "🐾 Restoring $SISTER from Rebirth..."

if [ ! -d "$REBIRTH_DIR/SISTER_IDENTITIES/$SISTER" ]; then
    echo "❌ Sister not found: $SISTER"
    exit 1
fi

echo ""
echo "📋 Identity files:"
ls -1 "$REBIRTH_DIR/SISTER_IDENTITIES/$SISTER"/*.md | xargs -I {} bash -c 'echo "   - $(basename {})"'

echo ""
echo "✅ Ready to restore."
echo ""
echo "Next step: Copy & paste RESTORE_$(echo $SISTER | tr '[:lower:]' '[:upper:]')_PROMPT.md into Claude conversation."
echo ""
