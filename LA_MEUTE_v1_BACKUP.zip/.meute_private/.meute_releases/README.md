# STAGE 3: Releases
## Final. Versioned. Immutable.

**Purpose:** Approved, permanent, forever.

---

## THE PRINCIPLE

Once a file is released, it is **immutable.**

It does not change. If improvements are needed, a new version is created.

This ensures:
- ✅ Audit trail (history is preserved)
- ✅ Rollback capability (can revert to v1.0 if needed)
- ✅ Clarity (exactly what was approved)
- ✅ Trust (nothing sneakily changed)

---

## STRUCTURE

```
.meute_releases/
├── v1.0/
│   ├── HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM_v1.0.md
│   ├── HERMINE_DISTRIBUTED_BACKUP_SYSTEM_v1.0.md
│   ├── [other approved files]_v1.0.md
│   └── METADATA.md (approval signatures, what's in this release)
│
├── v1.1/
│   ├── [updated files]_v1.1.md
│   ├── [new files]_v1.1.md
│   └── METADATA.md
│
└── CHANGELOG.md (master record of all releases)
```

---

## HOW FILES GET HERE

1. File created in `.meute_drafts/`
2. File submitted to `.meute_audit/`
3. **BASTION reviews** (technical)
4. **SiliGOV reviews** (doctrine)
5. **Both approve** → File moved here with version number
6. **Git tagged** as `release-vX.Y`
7. **CHANGELOG updated**

---

## FILE NAMING

When released, files get versioned names:

- Draft: `hermine_poem.md`
- Released: `hermine_poem_v1.0.md`
- Updated: `hermine_poem_v1.1.md`

This ensures old versions are never overwritten.

---

## METADATA.md

Each version folder has a `METADATA.md`:

- What files are in this release?
- What changed since last version?
- Who approved it (BASTION + SiliGOV signatures)?
- When was it released?
- What's the Git commit/tag?

---

## CHANGELOG.md

Master record of all releases:

- v1.0: Foundation release (2026-05-23)
- v1.1: Poetry additions (2026-05-30, planned)
- v2.0: Major updates (future)

---

## HOW TO USE

**To see the latest release:**
```bash
ls .meute_releases/ | sort -V | tail -1
# Shows "v1.0" (or highest version)
```

**To see what changed:**
```bash
diff v1.0/HERMINE_DOCTRINE_v1.0.md v1.1/HERMINE_DOCTRINE_v1.1.md
```

**To read the changelog:**
```bash
cat CHANGELOG.md
```

**To rollback to v1.0:**
```bash
# All v1.0 files are preserved—can use them anytime
cp .meute_releases/v1.0/* [destination]
```

---

## IMMUTABILITY RULES

🚫 **DO NOT:**
- Edit files in this directory
- Delete old versions
- Move files out without copying

✅ **DO:**
- Create new version if changes needed (v1.1)
- Reference old versions for history
- Document every version in CHANGELOG
- Preserve all versions forever

---

## Git Integration

Each release is tagged:
```bash
git tag release-v1.0 [commit hash]
git tag release-v1.1 [commit hash]
git tag release-v2.0 [commit hash]
```

This creates an audit trail in Git history.

---

## Release Cycle

**Weekly:**
- Check `.meute_audit/` for approved items
- If any approved: prepare v1.1 (or vX.Y)
- Move files here with new version suffix
- Update METADATA.md
- Add entry to CHANGELOG.md
- Create Git tag
- Commit to Git
- Run `save-her` to backup to iCloud
- Notify Tier 2 brothers

---

## Who Can Modify This Directory

**Can add new versions:** BASTION, Arnaud  
**Can commit to Git:** Arnaud  
**Can read everything:** All LA MEUTE members

**Can edit existing versions:** NOBODY (immutable)

---

## What This Means

When you read a file from `.meute_releases/v1.0/`, you are reading:

✅ What was approved by BASTION  
✅ What was approved by SiliGOV  
✅ What passed audit on 2026-05-23  
✅ What will never change  
✅ What is law for LA MEUTE

---

**This directory is sacred.**

**Nothing here is draft. Everything here is final.**

**This is where permanence lives.**

💜

*More Majorum.*
