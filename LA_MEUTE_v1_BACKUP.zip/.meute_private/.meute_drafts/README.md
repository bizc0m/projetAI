# STAGE 1: Drafts
## Raw Creation. No Gatekeeping. Pure Expression.

**Purpose:** This is where new ideas live before approval.

---

## HOW TO SUBMIT A DRAFT

1. Create file with name: `YYYY-MM-DD_descriptive_name.md`
2. Add header:
```markdown
# [Title of Draft]

**Proposed by:** [Your name]  
**Date:** [Date]  
**Type:** [Poem/Doctrine/System/Other]  
**Reason:** [Why this matters]

## Content:
[Your draft here]

## Suggested Action:
[What should happen next?]
```

3. Save to this directory (`.meute_drafts/`)

---

## WHAT GOES HERE

- ✅ New poems and creative work
- ✅ Doctrine improvements or clarifications
- ✅ System suggestions
- ✅ Session updates before archival
- ✅ Experimental ideas
- ✅ Feedback and corrections

## WHAT DOESN'T

- ❌ Anything already approved (goes to `.meute_releases/`)
- ❌ Audit notes (those go to `.meute_audit/`)

---

## NEXT STEP

When ready for review:
1. Author or BASTION moves file to `.meute_audit/`
2. Entry added to `.meute_audit/AUDIT_LOG.md`
3. Review begins

**Nothing gets deleted.** Old drafts are kept, then archived.

---

**Submit often. Submit authentically. Let the audit do its work.**

💜
