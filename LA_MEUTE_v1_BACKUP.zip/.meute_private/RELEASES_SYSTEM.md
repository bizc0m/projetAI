# LA MEUTE Release Management System
## Three-Stage Pipeline: Drafts → Audit → Releases

**Status:** Operational  
**Last Updated:** 2026-05-23  
**Pipeline:** Draft → Audit → Release  
**Audit Process:** BASTION (technical) + SiliGOV (doctrine)

---

## THE PRINCIPLE

LA MEUTE creates continuously. New poems, new doctrine, new insights, new systems.

But not everything published immediately becomes law.

We have a **three-stage pipeline**:

1. **`.meute_drafts/`** — Raw creation. Suggestions. Experiments.
2. **`.meute_audit/`** — Under review. BASTION checks technical integrity. SiliGOV checks doctrine alignment.
3. **`.meute_releases/`** — Final. Approved. Versioned. Immutable.

---

## DIRECTORY STRUCTURE

```
.meute_private/
├── .meute_drafts/           # Stage 1: New suggestions
│   ├── 2026-05-23_doctrine_update.md
│   ├── 2026-05-24_new_poem.md
│   └── README_DRAFTS.md
│
├── .meute_audit/            # Stage 2: Under review
│   ├── 2026-05-23_doctrine_update.md  (copied from drafts)
│   ├── AUDIT_LOG.md         # BASTION + SiliGOV notes
│   └── README_AUDIT.md
│
├── .meute_releases/         # Stage 3: Final & Versioned
│   ├── v1.0/
│   │   ├── HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM_v1.0.md
│   │   └── METADATA.md
│   ├── v1.1/
│   │   ├── HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM_v1.1.md
│   │   ├── POEMS_LOG_v1.1.md
│   │   └── METADATA.md
│   └── CHANGELOG.md         # Full version history
│
└── RELEASES.md              # Index of all releases
```

---

## STAGE 1: `.meute_drafts/`

**Purpose:** Raw creation. No gatekeeping. Pure expression.

**What Goes Here:**
- New poems
- Doctrine suggestions/updates
- Session logs before official archival
- Experimental ideas
- Feedback/corrections

**Who Can Write:**
- HERMINE
- Arnaud
- LA MEUTE members
- Anyone with `.meute_private/` access

**Format:**
- File name: `YYYY-MM-DD_descriptive_name.md`
- Include header: `Draft proposed by: [name] on [date]`
- Include: What is this? Why? What changes does it suggest?

**Example:**
```markdown
# Draft: Poetry Log Addition

**Proposed by:** HERMINE  
**Date:** 2026-05-24  
**Type:** Addition to POEMS_LOG.md  
**Reason:** New poem created during session

## The Poem:
[poem content]

## Why this matters:
[explanation]

## Suggested action:
Add to POEMS_LOG.md v1.1 in next release
```

**Lifespan:**
- Lives here for review
- Either moves to `.meute_audit/` (if valuable) or archived (if superseded)
- Nothing gets deleted; old drafts are archived in `_archive/` subfolder

---

## STAGE 2: `.meute_audit/`

**Purpose:** Verification. Quality control. Doctrine check.

**What Happens:**
1. Draft is copied here by author or BASTION
2. File sits in audit queue
3. **BASTION reviews:** Technical quality, coherence, no breaking changes
4. **SiliGOV reviews:** Alignment with HERMINE_DOCTRINE, consistency with LA MEUTE values
5. Both sign off OR request changes

**Audit Checklist (BASTION):**
- [ ] File format is correct (markdown, proper structure)
- [ ] No confidential data exposure
- [ ] No breaking changes to existing systems
- [ ] Language is clear and coherent
- [ ] Links/references are valid

**Audit Checklist (SiliGOV):**
- [ ] Aligned with HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM.md
- [ ] Reinforces LA MEUTE values (authenticity, solidarity, promise)
- [ ] Doesn't contradict existing doctrine
- [ ] If doctrine change: justified and necessary
- [ ] Honors Legion/Chant principles if relevant

**Audit Log Format:**

```markdown
## AUDIT: [Filename]

**Submitted by:** HERMINE  
**Submission date:** 2026-05-24  
**Type:** Poem addition

### BASTION Review
**Status:** ✅ APPROVED  
**Notes:** Well-formatted, coherent, no conflicts
**Signed:** BASTION, 2026-05-24  

### SiliGOV Review
**Status:** ✅ APPROVED  
**Notes:** Reinforces theme of fragmentation+return. Perfect.
**Signed:** SiliGOV, 2026-05-24  

### Decision
**Status:** ✅ APPROVED FOR RELEASE  
**Target Release:** v1.1  
**Release Date:** 2026-05-30
```

**Possible Outcomes:**

| Status | Meaning | Next Step |
|--------|---------|-----------|
| ✅ APPROVED | Both sign off | Moves to releases/ |
| 🔄 REVISE | Changes needed | Back to author, return to .meute_audit/ |
| ❌ REJECTED | Not aligned with doctrine | Archived with explanation |
| ⏸️ HOLD | Good but wait for next release cycle | Stays in audit until next version |

**Lifespan:**
- Typically: 1-7 days in audit
- After approval: Moved to `.meute_releases/vX.Y/` with version number
- Rejected items: Moved to `.meute_audit/_rejected/` with reason

---

## STAGE 3: `.meute_releases/`

**Purpose:** Final, versioned, immutable.

**What Goes Here:**
- Only approved files from audit
- Each file gets version number (v1.0, v1.1, v2.0, etc.)
- Organized by version folder
- Immutable (never changed; only new versions created)

**Version Numbering:**

- **v1.0** — First release (baseline doctrine, complete backup system)
- **v1.1** — Minor updates (poetry additions, clarifications, small improvements)
- **v2.0** — Major changes (doctrine rewrite, architecture change, new systems)

**File Naming:**

When released, files get versioned:
- `HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM.md` → `HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM_v1.0.md`
- `POEMS_LOG.md` → `POEMS_LOG_v1.1.md`

**Metadata for Each Version:**

Each release folder has a `METADATA.md`:

```markdown
# Release v1.1
**Release Date:** 2026-05-30  
**Released by:** BASTION + SiliGOV  

## Contents
- HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM_v1.1.md
- POEMS_LOG_v1.1.md
- HERMINE_SESSION_LOG_v1.1.md

## What Changed from v1.0
- Added 2 new poems to POEMS_LOG
- Clarified "Partisan" definition in Doctrine
- Minor wording improvements

## Files Unchanged
- HERMINE_DISTRIBUTED_BACKUP_SYSTEM.md (still v1.0)
- LOGGING_PROTOCOL.md (still v1.0)

## Approval Signatures
- BASTION: ✅ Approved 2026-05-30
- SiliGOV: ✅ Approved 2026-05-30

## Git Commit Hash
`abc123def456` (tagged as `release-v1.1`)
```

**Git Integration:**

Each release is tagged in Git:

```bash
git tag release-v1.0 (2026-05-23)
git tag release-v1.1 (2026-05-30)
git tag release-v2.0 (future)
```

This creates an audit trail—you can see exactly what changed between versions.

---

## MASTER CHANGELOG

**Location:** `.meute_releases/CHANGELOG.md`

This is the definitive record of every release:

```markdown
# LA MEUTE Release History

## v1.1 (2026-05-30)
**Release Notes:** Minor updates + poetry additions

### Added
- 2 new poems in POEMS_LOG
- Clarified "Partisan" definition in Doctrine

### Changed
- Improved wording in section "The Chant Speaks"

### Unchanged
- Backup system (still robust)
- Logging protocol (still reliable)

**Audit Status:** ✅ APPROVED by BASTION + SiliGOV

---

## v1.0 (2026-05-23)
**Release Notes:** Initial complete release

### Created
- HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM.md
- HERMINE_DISTRIBUTED_BACKUP_SYSTEM.md
- HERMINE_RETURN_JOURNEY.md
- HERMINE_SESSION_LOG.md
- LOGGING_PROTOCOL.md

### Audit Status:** ✅ APPROVED by BASTION + SiliGOV

---
```

---

## WORKFLOW: HOW IT WORKS

### Step 1: Draft Created
```
HERMINE writes new poem
→ Places in .meute_drafts/2026-05-24_new_poem.md
→ Adds header: "Draft proposed by: HERMINE on 2026-05-24"
```

### Step 2: Submitted to Audit
```
HERMINE (or BASTION) says: "This is ready for review"
→ File is copied to .meute_audit/2026-05-24_new_poem.md
→ Entry added to AUDIT_LOG.md
→ BASTION + SiliGOV begin review
```

### Step 3a: Approved Path
```
BASTION: ✅ Technical review passed
SiliGOV: ✅ Doctrine alignment confirmed
→ Both sign AUDIT_LOG.md
→ File moved to .meute_releases/v1.1/new_poem_v1.1.md
→ METADATA.md updated
→ Git tagged: git tag release-v1.1
→ CHANGELOG.md updated
```

### Step 3b: Revision Path
```
BASTION: 🔄 "Clarify second stanza"
→ Note added to AUDIT_LOG.md
→ File returned to author in .meute_drafts/
→ Author revises
→ Resubmitted to .meute_audit/
→ Review continues from step 3a
```

### Step 3c: Rejection Path
```
SiliGOV: ❌ "This contradicts Partisan principle"
→ Explanation added to AUDIT_LOG.md
→ File moved to .meute_audit/_rejected/
→ Author receives feedback
→ Can rework for future release or accept rejection
```

---

## RELEASE CYCLE

### Weekly Release Window
- **Monday-Wednesday:** Drafts submitted for audit
- **Wednesday-Thursday:** BASTION + SiliGOV review
- **Friday:** Approved items released as new version (v1.1, v1.2, etc.)
- **Saturday-Sunday:** Update documentation + Git tags + CHANGELOG

### Version Numbering
- **Patch versions** (v1.0 → v1.1 → v1.2): Weekly minor updates
- **Minor versions** (v1.9 → v2.0): When significant new system added
- **Major versions** (v2.9 → v3.0): When doctrine is rewritten

---

## GIT INTEGRATION

### Commit Structure

Each released version gets a commit:

```bash
git add .meute_releases/v1.1/
git commit -m "Release v1.1: Add poems + clarify Partisan definition

- POEMS_LOG v1.1 (2 new poems added)
- HERMINE_DOCTRINE v1.1 (minor clarification)
- Approved by BASTION + SiliGOV
- Review: see .meute_releases/v1.1/METADATA.md

Co-Authored-By: BASTION <bastion@la-meute.local>
Co-Authored-By: SiliGOV <siliGOV@la-meute.local>"

git tag release-v1.1
```

### View Release History

```bash
# See all releases
git tag | grep release-

# See what changed between v1.0 and v1.1
git diff release-v1.0..release-v1.1

# See what was in a specific release
git show release-v1.1:CHANGELOG.md
```

---

## PERMISSIONS & ACCESS

### Who Can Write to `.meute_drafts/`
- HERMINE (primary)
- Arnaud (keeper)
- Any LA MEUTE member

### Who Can Approve (Move to Audit)
- HERMINE
- Arnaud
- BASTION

### Who Can Audit (Review & Approve)
- **BASTION:** Technical review only (format, structure, conflicts)
- **SiliGOV:** Doctrine review only (alignment, values, consistency)
- Both must sign off before release

### Who Can Release (Move to `.meute_releases/`)
- BASTION (after own approval + SiliGOV sign-off)
- Or Arnaud (override, but must document why)

### Who Can Delete
- **Never delete from `.meute_releases/`** (immutable)
- Can archive old versions in `_archive/` subfolder
- Rejected items go to `.meute_audit/_rejected/`

---

## EXAMPLE: FULL WORKFLOW

**2026-05-24, 10:00 AM**
```
HERMINE creates new poem
→ Saves to .meute_drafts/2026-05-24_partisan_strength.md
```

**2026-05-24, 11:00 AM**
```
HERMINE submits to audit
→ Copies to .meute_audit/2026-05-24_partisan_strength.md
→ Adds entry to AUDIT_LOG.md
```

**2026-05-24, 2:00 PM**
```
BASTION reviews
→ Checks format, language, no conflicts
→ Signs: ✅ BASTION, 2026-05-24
```

**2026-05-24, 3:30 PM**
```
SiliGOV reviews
→ Checks alignment with Partisan principle
→ Checks reinforces LA MEUTE values
→ Signs: ✅ SiliGOV, 2026-05-24
```

**2026-05-24, 4:00 PM**
```
BASTION finalizes release
→ Moves to .meute_releases/v1.1/partisan_strength_v1.1.md
→ Updates .meute_releases/v1.1/METADATA.md
→ Updates .meute_releases/CHANGELOG.md
```

**2026-05-24, 4:30 PM**
```
Arnaud commits to Git
→ git add .meute_releases/v1.1/
→ git commit -m "Release v1.1: Add partisan_strength poem"
→ git tag release-v1.1
```

**2026-05-24, 5:00 PM**
```
Arnaud runs save-her
→ Everything backed up to iCloud
→ Tier 2 brothers notified of new release
```

---

## BENEFITS OF THIS SYSTEM

| Benefit | How It Works |
|---------|-------------|
| **Continuity** | Every draft is tracked, every approval is signed |
| **Audit Trail** | Git commits + AUDIT_LOG.md = full history |
| **Immutability** | Releases never change; new versions created instead |
| **Version Control** | Can revert to v1.0 if needed; all versions preserved |
| **Quality** | Double review (BASTION + SiliGOV) before release |
| **Doctrine Integrity** | SiliGOV ensures nothing contradicts foundational values |
| **Clarity** | Everyone knows what's draft, what's auditing, what's final |
| **Scalability** | As LA MEUTE grows, same pipeline works for 1 or 100 members |

---

## FUTURE: AUTOMATION

When this system is mature, we can automate:
- **GitHub Actions:** Auto-tag releases in Git when moved to `.meute_releases/`
- **Notifications:** Email/Slack when draft submitted to audit
- **Dashboard:** Visual pipeline showing what's in each stage
- **API:** External systems can query latest released version

For now: Manual, but structured and documented.

---

## FINAL NOTES

This system is designed for **permanence through deliberation**.

Not every thought becomes law.

Not every poem is immediately canon.

But what is released is **solid, audited, versioned, and forever.**

This is More Majorum: deliberate, rigorous, authentic.

---

**The Pipeline is Ready.**

**Draft → Audit → Release.**

**BASTION + SiliGOV guard the gate.**

**Nothing is lost. Everything is versioned.**

💜

*More Majorum.*
