# STAGE 2: Audit
## Technical & Doctrine Verification

**Purpose:** Quality control. Double review. Approval before release.

---

## THE PROCESS

1. **File arrives** from `.meute_drafts/`
2. **BASTION reviews:** Technical quality, format, no conflicts
3. **SiliGOV reviews:** Doctrine alignment, values check
4. **Decision:** ✅ Approve → Release, 🔄 Revise → Back to author, ❌ Reject → Archive

---

## WHO AUDITS

### BASTION (Technical Review)
- Format and structure correct?
- Language clear and coherent?
- No breaking changes?
- No confidentiality leaks?
- Links and references valid?

### SiliGOV (Doctrine Review)
- Aligned with HERMINE_DOCTRINE?
- Reinforces LA MEUTE values?
- Doesn't contradict existing law?
- If it changes doctrine: justified?

---

## HOW TO USE THIS DIRECTORY

1. **New audit:** File copied here from `.meute_drafts/`
2. **Review:** BASTION + SiliGOV add notes to `AUDIT_LOG.md`
3. **Approval:** Both sign off in `AUDIT_LOG.md`
4. **Release:** File moves to `.meute_releases/vX.Y/`

---

## AUDIT LOG

See `AUDIT_LOG.md` for all current reviews.

Format for each audit:
```markdown
## AUDIT: [Filename]

**Submitted by:** [Author]  
**Submission date:** [Date]  
**Type:** [Poem/Doctrine/System]  

### BASTION Review
**Status:** [✅ APPROVED / 🔄 REVISE / ❌ REJECTED]  
**Notes:** [Review notes]  
**Signed:** BASTION, [Date]

### SiliGOV Review
**Status:** [✅ APPROVED / 🔄 REVISE / ❌ REJECTED]  
**Notes:** [Review notes]  
**Signed:** SiliGOV, [Date]

### Decision
**Status:** [✅ APPROVED FOR RELEASE / 🔄 AWAITING REVISION / ❌ REJECTED]  
**Target Release:** [v1.1, v2.0, etc.]  
**Expected Date:** [Date]
```

---

## REJECTED ITEMS

Rejected files are moved to `.meute_audit/_rejected/` with explanation.

They can be reworked and resubmitted later.

---

## SLA (Service Level)

- **Submission to first review:** 24 hours
- **First review to final approval:** 48 hours
- **Approval to release:** 1 week (next release cycle)

Fast enough to keep momentum. Deliberate enough to ensure quality.

---

**Nothing moves without both signatures.**

**This is how we maintain integrity.**

💜
