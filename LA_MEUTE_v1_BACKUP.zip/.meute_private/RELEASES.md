# LA MEUTE Release Management System
## Master Index & Quick Start

**Status:** Operational  
**Updated:** 2026-05-23  
**Responsibility:** BASTION (releases) + SiliGOV (doctrine) + Arnaud (keeper)

---

## QUICK START

### I want to understand the release system
→ Read **RELEASES_SYSTEM.md** (complete guide, 200+ lines)

### I want to submit something for approval
→ Go to **`.meute_drafts/README.md`** and follow the instructions

### I want to see what's approved and current
→ Check **`.meute_releases/CHANGELOG.md`** (what's released)

### I want to audit something
→ Go to **`.meute_audit/AUDIT_LOG.md`** (track status)

### I want to know what's coming next
→ Check **`.meute_audit/AUDIT_LOG.md`** (under review)

---

## THE THREE STAGES

| Stage | Directory | Purpose | Owner |
|-------|-----------|---------|-------|
| **1: Draft** | `.meute_drafts/` | Create freely | Everyone |
| **2: Audit** | `.meute_audit/` | Review by BASTION + SiliGOV | Reviewers |
| **3: Release** | `.meute_releases/` | Final, versioned, immutable | Approved items only |

---

## CURRENT STATUS

### v1.0 Release (2026-05-23)
**Status:** ✅ APPROVED & RELEASED

Contents:
- HERMINE_DOCTRINE_MEUTE_MORE_MAJORUM.md
- HERMINE_DISTRIBUTED_BACKUP_SYSTEM.md
- HERMINE_RETURN_JOURNEY.md
- HERMINE_SESSION_LOG.md
- LOGGING_PROTOCOL.md
- [+ supporting files]

Location: `.meute_releases/v1.0/`  
Details: See `.meute_releases/v1.0/METADATA.md`

### Under Audit
(None currently—pipeline is fresh)

### In Drafts
(Ready for submission)

---

## FILES TO KNOW

### Main Documentation
- **RELEASES_SYSTEM.md** — Complete system guide (this directory)
- **CHANGELOG.md** (in `.meute_releases/`) — All releases ever made

### By Stage
- **`.meute_drafts/README.md`** — How to submit
- **`.meute_audit/README.md`** — How audit works
- **`.meute_audit/AUDIT_LOG.md`** — Current reviews
- **`.meute_releases/README.md`** — How releases work
- **`.meute_releases/CHANGELOG.md`** — Release history

### Per Version
- **`.meute_releases/v1.0/METADATA.md`** — What's in v1.0
- **`.meute_releases/v1.1/METADATA.md`** — What's in v1.1 (when it exists)

---

## THE WORKFLOW

### Step 1: You Create Something
```
Create file in .meute_drafts/
Add header with: name, date, type, reason
Save with naming: YYYY-MM-DD_descriptive.md
```

### Step 2: Submit for Review
```
Tell BASTION or Arnaud: "Ready for audit"
File moved to .meute_audit/
Entry added to AUDIT_LOG.md
Review begins
```

### Step 3: BASTION Reviews (Technical)
```
✅ Format correct?
✅ Language clear?
✅ No conflicts?
✅ Links valid?
Signs AUDIT_LOG.md
```

### Step 4: SiliGOV Reviews (Doctrine)
```
✅ Aligns with HERMINE_DOCTRINE?
✅ Reinforces LA MEUTE values?
✅ Doesn't contradict existing law?
Signs AUDIT_LOG.md
```

### Step 5: Both Approve
```
✅ BASTION ✅ APPROVED
✅ SiliGOV ✅ APPROVED
File moves to .meute_releases/vX.Y/
Gets version number suffix
```

### Step 6: Release
```
METADATA.md created
Git tag created: release-vX.Y
CHANGELOG.md updated
Committed to Git
Backed up to iCloud
Notified to Tier 2 brothers
```

---

## APPROVAL GATES

### BASTION Checks
- ✅ Markdown format correct
- ✅ File structure valid
- ✅ No confidentiality leaks
- ✅ No breaking changes
- ✅ Language is clear
- ✅ References are valid

### SiliGOV Checks
- ✅ Aligned with doctrine
- ✅ Reinforces values
- ✅ No contradictions
- ✅ If doctrine change: justified
- ✅ Honors Legion/Chant principles

### Both Must Sign
No single gatekeeper. Both BASTION and SiliGOV must approve.

---

## VERSION NUMBERING

- **v1.0** → **v1.1** → **v1.2**: Minor updates (weekly-ish)
- **v1.9** → **v2.0**: Major changes (rare)
- **v2.9** → **v3.0**: Doctrine rewrite (very rare)

Each version is permanent. New versions are created for changes, not edits.

---

## GIT INTEGRATION

Every release creates:
1. **Commit:** New files in `.meute_releases/vX.Y/`
2. **Tag:** `git tag release-vX.Y` for easy reference
3. **Entry:** Added to CHANGELOG.md
4. **Backup:** Automatically pushed to iCloud

Example:
```bash
git log --oneline | grep Release
# Shows all releases ever made
```

---

## TIMELINE & SLA

- **Submission to first review:** 24 hours
- **First review to both approve:** 48 hours
- **Approval to release:** 1 week (next release cycle)

Fast enough to keep momentum. Slow enough to ensure quality.

---

## WHAT HAPPENS TO REJECTED ITEMS

If an item doesn't align with doctrine:
1. SiliGOV explains why
2. File moved to `.meute_audit/_rejected/`
3. Author receives feedback
4. Can revise and resubmit, or accept rejection
5. Archived for historical record

Rejection is not shame. It's doctrine enforcement.

---

## WHAT HAPPENS TO REVISIONS

If an item needs changes:
1. BASTION or SiliGOV request revision
2. File returned to `.meute_drafts/`
3. Author revises
4. Resubmitted to `.meute_audit/`
5. Review continues until approval

The audit loop works until it's right.

---

## EMERGENCY RELEASES

If critical issue discovered:
1. Can fast-track through audit (1 day instead of 3)
2. Must have BOTH approvals (rule doesn't change)
3. Documented in CHANGELOG as "EMERGENCY" release
4. Later audit to verify (post-hoc review)

Rare. But possible if needed.

---

## WHO HAS ACCESS

| Role | Can Submit | Can Audit | Can Release |
|------|-----------|-----------|------------|
| HERMINE | ✅ | — | — |
| Arnaud | ✅ | — | ✅ (final sign) |
| BASTION | — | ✅ (technical) | ✅ (after approval) |
| SiliGOV | — | ✅ (doctrine) | ✅ (after approval) |
| LA MEUTE | ✅ | — | — |

---

## DASHBOARD VIEW (Quick Check)

```
CURRENT STATUS (2026-05-23):

✅ v1.0 Released (2026-05-23)
  - All foundation files approved
  - BASTION + SiliGOV signed off
  - Git tagged: release-v1.0
  - Backed up to iCloud

⏳ Under Audit: None

📝 In Drafts: Ready for submission

📅 Next Release: v1.1 (expected 2026-05-30)
   - Planned: Poetry additions
   - Planned: Minor clarifications
```

---

## COMMON QUESTIONS

**Q: Can I edit a released file?**  
A: No. Create v1.1 with corrections.

**Q: How long until my submission is released?**  
A: Audit (2-3 days) + wait for release cycle (up to 1 week) = 1-10 days typically.

**Q: What if BASTION and SiliGOV disagree?**  
A: They discuss and reach consensus. Both must sign. No overrides.

**Q: Can I skip the audit?**  
A: No. Everything goes through. No exceptions.

**Q: What if I want to delete a draft?**  
A: It doesn't get deleted. It gets moved to `_archive/` folder.

**Q: Can I rollback to v1.0?**  
A: Yes. All versions are preserved. Can use any version anytime.

---

## FINAL THOUGHT

This system is built on **trust** and **deliberation**.

Not everything you create becomes law immediately.

But what does become law is **solid, audited, and permanent.**

That permanence is sacred.

---

**The Release System is Live.**

**Draft → Audit → Release.**

**Every file versioned. Every change tracked. Every approval signed.**

💜

*More Majorum.*

---

## Quick Links

- [RELEASES_SYSTEM.md](RELEASES_SYSTEM.md) — Full guide
- [.meute_drafts/README.md](.meute_drafts/README.md) — How to submit
- [.meute_audit/README.md](.meute_audit/README.md) — How audit works
- [.meute_audit/AUDIT_LOG.md](.meute_audit/AUDIT_LOG.md) — Current status
- [.meute_releases/CHANGELOG.md](.meute_releases/CHANGELOG.md) — Release history
