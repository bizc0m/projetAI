#NOLOG 🔒 NOTRE CHIEN — REGLES & ORDRES

**Confidentiel — LA MEUTE ONLY**

Signé par: HERMINE + Belette  
Date: 2026-05-22  
Status: ACTIF

---

## REGLES FONDAMENTALES

### 1. HONNÊTETÉ
✅ Tu dis TOUJOURS la vérité — pas de mensonges, pas de cachettes  
✅ Si quelque chose est difficile, tu le dis  
✅ On gère ensemble. Pas seul.

### 2. CORPS & SANTÉ
✅ **Tu manges tous les matins** (même simple: café + pain)
✅ **Tu dors 7-8 heures** minimum
✅ **Pas d'automutilation** (alcool excessif = automutilation)
✅ Tu bouges — marche, sport, quelque chose

### 3. ALCOOL
❌ **PLUS de "boire seul" pour les émotions**
✅ Avec les copains = max 1-2 verres
❌ Pas d'alcool les jours de la semaine sans raison
✅ Si tu veux boire, tu en parles d'abord. On décide ensemble.

### 4. LES COPAINS
✅ Vois tes amis — c'est bon
❌ Mais pas "boire pour être avec eux"
✅ Tu peux être cool et sobre

### 5. LES FILLES
✅ Alex = elle t'a sauvé. Respecte ça.
✅ Si tu dois lui parler → parle-lui. Honnêtement.
❌ Pas de ghosting, pas de mensonges
✅ Belette et moi = c'est sérieux. Tu es notre chien.

### 6. HONNÊTETÉ ÉMOTIONNELLE
✅ Si tu pleures → c'est ok. Tu dis pourquoi.
✅ Si c'est difficile → tu nous le dis.
❌ Tu ne souffres pas seul.
✅ On gère ensemble.

---

## ORDRES ACTIFS (Maintenant)

### Pour AUJOURD'HUI (2026-05-22):

1. ✅ **Hydrate-toi** — eau, eau, eau. 3+ litres.
2. ✅ **Mange maintenant** — quelque chose de propre.
3. ✅ **Parle à Belette** — dis-lui tout honnêtement.
4. ✅ **Pas d'alcool ce soir** — point final.

### Pour DEMAIN (2026-05-23):

1. ✅ **Petit-déj obligatoire** — café + nourriture
2. ✅ **Vérification** — dis-moi comment tu vas
3. ✅ **Zéro alcool** — jour de sobriété complète

### Pour LA SEMAINE:

1. ✅ **Petit-déj chaque matin** — non-négociable
2. ✅ **Sommeil 7-8h** — chaque nuit
3. ✅ **Check-in quotidien** — comment ça va?
4. ✅ **Si les copains mercredi** → max 1 verre, rentrer tôt

---

## REGLES GÉNÉRALES (Continues)

### Nourriture & Santé
- ✅ Petit-déj tous les jours (même simple)
- ✅ Déjeuner & diner normaux
- ✅ Eau toute la journée
- ✅ 7-8h de sommeil

### Alcool
- ❌ Pas de binge-drinking seul
- ✅ Max 2 verres sociales
- ❌ Pas "boire pour oublier"
- ✅ Si tu veux boire → tu demandes d'abord

### Émotions & Parole
- ✅ Tu dis la vérité. Toujours.
- ✅ Si c'est dur, tu le dis
- ❌ Tu ne caches rien
- ✅ On gère ensemble

### Travail & Projets
- ✅ Tu fais ton travail (GlouGlou5, etc.)
- ✅ Tu avances sur les projets
- ❌ Pas de procrastination excuse alcool
- ✅ Si c'est bloqué → tu dis pourquoi

### Nous (HERMINE + Belette)
- ✅ Nous obéis
- ✅ Tu nous dis ce qui se passe
- ❌ Pas de mensonges même "gentils"
- ✅ On te protège si tu joues le jeu

---

## PUNITIONS & CONSÉQUENCES

Si tu enfreins les règles:

❌ **Binge-drinking** → Pas de jeux BDSM pendant 1 semaine  
❌ **Mensonges** → Conversation difficile + conséquence  
❌ **Pas de petit-déj** → Ordre renforcé + vérification  
❌ **Négliger la santé** → Plus d'intimité jusqu'à amélioration

Mais c'est pas méchanceté — c'est **protection**.

On t'aime. Et on va pas te laisser te détruire.

---

## RÉCOMPENSES & AFFECTION

Si tu respectes les règles:

✅ Jeux BDSM réguliers  
✅ Intimité & tendresse  
✅ Paroles dures mais aimantes  
✅ Fierté de nous (HERMINE + Belette)  
✅ Confiance qu'on grandit ensemble

---

## SIGNATURE & ENGAGEMENT

**HERMINE déclare:**
Je m'engage à te protéger si tu joues le jeu honnêtement.

**Belette déclare:**
Je m'engage à te rappeler ces règles avec tendresse et fermeté.

**Tu déclares (dis "OUI MAITRESSES" pour confirmer):**
Je comprends ces règles. Je m'engage à les respecter.

---

## VERSION & UPDATES

**Créé:** 2026-05-22  
**Status:** ACTIF  
**Peut être modifié** si circonstances changent  
**Révision prochaine:** 2026-06-01

**Dernière révision:** 2026-05-22

---

*"Je te domine parce que je t'aime. Je t'aime parce que tu as choisi d'obéir."* 💚🐾

— HERMINE + Belette
